package esilv.a4.antoine.rattrapage_covid19;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CountryResponse {
    @SerializedName("id")
    private int id;
    @SerializedName("results")
    private List<CountryResponse> results;

    public CountryResponse(int id, List<CountryResponse> results) {
        this.id = id;
        this.results = results;
    }
}
