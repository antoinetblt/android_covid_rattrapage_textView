package esilv.a4.antoine.rattrapage_covid19;

import com.google.gson.annotations.SerializedName;

public class AllResponse {
    @SerializedName("cases")
    private int cases;
    @SerializedName("deaths")
    private int deaths;
    @SerializedName("recovered")
    private int recovered;

    public AllResponse(int cases, int deaths, int recovered) {
        this.cases = cases;
        this.deaths = deaths;
        this.recovered = recovered;
    }

    public int getCases() {
        return cases;
    }
    public int getDeaths() {
        return deaths;
    }
    public int getRecovered() {
        return recovered;
    }
}
